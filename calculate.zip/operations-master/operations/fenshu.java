package com.jarvis.operations;

public class fenshu
{
  private int fenshu;
  private int fenmu;
  private int fenzi;

  public int getFenshu()
  {
    return this.fenshu;
  }
  public void setFenshu(int fenshu) {
    this.fenshu = fenshu;
  }
  public int getFenmu() {
    return this.fenmu;
  }
  public void setFenmu(int fenmu) {
    this.fenmu = fenmu;
  }
  public int getFenzi() {
    return this.fenzi;
  }
  public void setFenzi(int fenzi) {
    this.fenzi = fenzi;
  }
}